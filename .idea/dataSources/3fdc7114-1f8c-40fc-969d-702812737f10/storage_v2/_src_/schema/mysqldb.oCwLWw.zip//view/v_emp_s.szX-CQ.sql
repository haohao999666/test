create definer = root@localhost view v_emp_s as (select `mysqldb`.`emp`.`ENAME`    AS `部门名称`,
                                                        min(`mysqldb`.`emp`.`SAL`) AS `最低工资`
                                                 from `mysqldb`.`emp`
                                                 group by `mysqldb`.`emp`.`DEPTNO`);

