create definer = root@localhost view v_emp_2k_5k as (select `mysqldb`.`emp`.`ENAME` AS `ENAME`,
                                                            `mysqldb`.`emp`.`EMPNO` AS `EMPNO`,
                                                            `mysqldb`.`emp`.`SAL`   AS `SAL`
                                                     from `mysqldb`.`emp`
                                                     where `mysqldb`.`emp`.`SAL` between 2000 and 5000
                                                       and `mysqldb`.`emp`.`ENAME` like '%A%');

